<?php
$home = "../HomePage/login.php";
header('Location: ' . $home);
exit;