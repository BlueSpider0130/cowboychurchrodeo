<?php
$home = "HomePage/index.php";
header('Location: ' . $home);
exit;